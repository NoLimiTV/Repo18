from sys import argv, exit
from requests import get
from os import path, remove
from json import loads, load
from shutil import rmtree
from time import time
from urllib import urlretrieve, unquote
from xbmcaddon import Addon
from xbmcplugin import endOfDirectory, addDirectoryItem
from xbmcgui import ListItem, Dialog
from xbmcvfs import listdir, exists, mkdirs
from xbmc import translatePath, executebuiltin, getInfoLabel, executeJSONRPC, Player, log, convertLanguage

MyAddon = Addon()
MyScriptID = MyAddon.getAddonInfo('id')
MyTmp = translatePath(MyAddon.getAddonInfo('profile')).encode('utf-8')
MySubFolder = translatePath(path.join(MyTmp, 'subs')).encode('utf-8')
MyName = MyAddon.getAddonInfo('name')

def getDomain():
	try:
		response = get("https://raw.githubusercontent.com/NoLimiTV/repo/master/domain.txt", verify=False)
		data = loads(response.text)
		return data['result']
	except: 
		return "vpnmate.com"
		pass

def getParams(string=""):
	param=[]
	if string == "":
		paramstring=argv[2]
	else:
		paramstring=string
	if len(paramstring)>=2:
		params=paramstring
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def searchSub(imdb,season,episode,langs,langNames,domain,token):
	langs = "-".join(langs)

	if (season>0 and episode>0):
		filename = 'nolimitv.imdb.%s.%s.%s.%s.json' % (imdb, langs, season, episode)
		url = "https://opensubs.%s/subs/%s/%s.%s.%s.json?token=%s" % (domain, imdb, langs, season, episode,token)
	else:
		filename = 'nolimitv.imdb.%s.%s.json' % (imdb, langs)
		url = "https://opensubs.%s/subs/%s/%s.json?token=%s" % (domain, imdb, langs,token)

	json_object = cachingSearch(filename, url)
	if json_object != 0:
		for item_data in json_object:
			listitem = ListItem(label=convertLanguage(item_data["lang"], xbmc.ENGLISH_NAME), label2=item_data["name"],thumbnailImage=item_data["lang"], iconImage = str(int(item_data["score"])))
			listitem.setProperty( "sync", ("false", "true")[int(item_data["score"]) == 5] )
			url = "plugin://%s/?action=download&name=%s&id=%s&lang=%s" % (MyScriptID, item_data["name"], item_data["id"],item_data["lang"])
			addDirectoryItem(handle=int(argv[1]), url=url, listitem=listitem, isFolder=False)

def downloadSub(id,imdb,lang,domain,token):
	url = "https://opensubs.%s/subs/%s/%s/%s.srt?token=%s" % (domain, imdb,lang,id,token)
	try:
		mkdirs(MySubFolder)
	except Exception as err:
		pass
	subFile = path.join(MySubFolder, 'nolimitv.'+id+'.srt')
	if not path.exists(subFile):
		urlretrieve(url, subFile)
	if path.getsize(subFile) < 100:
		try:
			remove(subFile)
		except Exception as err:
			pass
		Dialog().ok("NolimiTV Upload Subtitle","Can't download subtitle. Try again later")
		return 0
	return subFile
	
def cachingSearch(filename, url):
	json_file = path.join(MyTmp, filename)
	if not path.exists(json_file) or not path.getsize(json_file) > 20 or (time()-path.getmtime(json_file) > 30*60):
		urlretrieve(url, json_file)
	if path.exists(json_file) and path.getsize(json_file) > 20:
		with open(json_file) as json_data:
			json_object = load(json_data)
		return json_object
	else:
		return 0

def wlog(msg):
	log((u"##**## [%s] %s" % (MyName, msg,)).encode('utf-8'), level=xbmc.LOGDEBUG)

# Main
if not exists(MyTmp):
	mkdirs(MyTmp)

params = getParams()
action = params['action']
domain = getDomain()
token = Addon(id='program.nolimitv').getSetting("token")

langs = []
langsName = []
if 'languages' in params:
	for lang in unquote(params['languages']).decode('utf-8').split(","):
		if lang == "Portuguese (Brazil)":
			lan = "pt"
		elif lang == "Greek":
			lan = "el"
		else:
			lan = convertLanguage(lang,xbmc.ISO_639_1)

		langs.append(lan)
		langsName.append(lang)

if 'lang' in params:
	lang = params['lang']
	
# Get imdb, season & episode
if Player().isPlaying():	# Take item params from Player
	playerid_query = '{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
	playerid = loads(executeJSONRPC(playerid_query))['result'][0]['playerid']
	imdb_id_query = '{"jsonrpc": "2.0", "method": "Player.GetItem", "params": {"playerid": '+str(playerid)+', "properties": ["imdbnumber"]}, "id": 1}'
	imdb = loads(executeJSONRPC(imdb_id_query))['result']['item']['imdbnumber']
	season = str(getInfoLabel("VideoPlayer.Season"))
	episode = str(getInfoLabel("VideoPlayer.Episode"))
else:   # Take item params from list
	imdb = getInfoLabel("ListItem.IMDBNumber")
	season = getInfoLabel("ListItem.Season")
	episode = getInfoLabel("ListItem.Episode")

if imdb[:2] != "tt":
	exit()
if season == '' or season < 1:
	season = 0
if episode == '' or episode < 1:
	episode = 0

if action == 'search':
		# Search NoLimiTV Recommended Subtitle
		link = "http://subs."+domain+"/?imdb=%s&season=%s&episode=%s"%(imdb,season,episode)
		response = get(link, verify=False)
		data = loads(response.text)

		for langName in data:
			listitem = ListItem(label=langName, label2="NoLimiTV Recommended Subtitle",thumbnailImage=convertLanguage(langName,xbmc.ISO_639_1), iconImage = str(5))
			listitem.setProperty("sync", "true")
			myurl = "plugin://%s/?action=download_direct&myurl=%s" % (MyScriptID, data[langName])
			addDirectoryItem(handle=int(argv[1]), url=myurl, listitem=listitem, isFolder=False)
			if langName in langsName:
				langsName.remove(langName)
				langs.remove(convertLanguage(langName,xbmc.ISO_639_1))
		
		# Search Opensubs
		if len(langs)>0:
			searchSub(imdb,season,episode, langs, langsName, domain, token)
		endOfDirectory(int(argv[1]))

elif action == 'download_direct':
	myurl = params['myurl']
	listitem = ListItem(label="download")
	addDirectoryItem(handle=int(argv[1]), url=myurl, listitem=listitem, isFolder=False)
	endOfDirectory(int(argv[1]))

elif action == 'download':
	id = params['id']
	sub = downloadSub(id,imdb,lang,domain,token)
	if sub!=0:
		listitem = ListItem(label=sub)
		addDirectoryItem(handle=int(argv[1]), url=sub, listitem=listitem, isFolder=False)
		endOfDirectory(int(argv[1]))
		MyAddon.setSetting("idSub",id)
	
	# Upload to NoLimiTV Recommended
	if MyAddon.getSetting("uploadAP") == "true" and sub!=0:
		response = get("https://subs."+domain+"/webupload.php?status=1&imdb=%s&season=%s&episode=%s"%(imdb,season,episode), verify=False)
		ap_object = loads(response.text)["result"]
		if ap_object["lang"][lang]==0:
			timeout = int(MyAddon.getSetting("timeout"))
			xbmc.sleep(timeout*1000)
			if MyAddon.getSetting("idSub")==id and Player().isPlaying():
				MyAddon.setSetting("idSub","0")
				i = Dialog().yesno("NoLimiTV Upload Subtitle","Media version: %s"%ap_object["version"],"This subtitle is 100% sync and match?")
				if i == 1:
					x = Dialog().yesno("NoLimiTV Upload Subtitle","Are you sure this subtitle is 100% sync and match ?","DON'T UPLOAD IF YOU AREN'T SURE!")
					if x == 1:
						response = get("https://subs."+domain+"/webupload.php?upload=1&lang=%s&imdb=%s&season=%s&episode=%s&subid=%s"%(lang,imdb,season,episode,id), verify=False)
						ap_upload = loads(response.text)["result"]
						if "error" in ap_upload:
							Dialog().ok("NoLimiTV Subtitles","%s"%ap_upload["error"])
						else:
							Dialog().ok("NoLimiTV Subtitles","Sub uploaded. Thank you!")

elif action == 'clean':
	try:
		rmtree(MyTmp)
	except Exception as err:
		pass
	executebuiltin((u'Notification(%s,"Cache Clean")' % MyName))